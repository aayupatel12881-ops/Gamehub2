package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.network.AuthNetwork
import com.example.network.AuthRequest
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import retrofit2.HttpException

sealed class AuthState {
    object Idle : AuthState()
    object Loading : AuthState()
    object Success : AuthState()
    data class Error(val message: String) : AuthState()
}

class AuthViewModel : ViewModel() {
    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState = _authState.asStateFlow()

    fun login(email: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val response = AuthNetwork.api.signIn(
                    apiKey = "AIzaSyBb1HR0vywNsoG3N6XD8QiRVvAJ5yfoAD8",
                    request = AuthRequest(email, password)
                )
                if (response.idToken != null) {
                    _authState.value = AuthState.Success
                } else {
                    _authState.value = AuthState.Error("Login failed")
                }
            } catch (e: HttpException) {
                _authState.value = AuthState.Error("Invalid credentials or error: ${e.code()}")
            } catch (e: Exception) {
                _authState.value = AuthState.Error("Network error: ${e.message}")
            }
        }
    }
}
