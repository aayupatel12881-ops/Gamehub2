package com.example.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

data class MathQuestion(
    val num1: Int,
    val num2: Int,
    val isAddition: Boolean
) {
    val answer: Int
        get() = if (isAddition) num1 + num2 else num1 - num2
        
    val display: String
        get() = if (isAddition) "$num1 + $num2" else "$num1 - $num2"
}

class RewardsViewModel : ViewModel() {
    private val _points = MutableStateFlow(0)
    val points = _points.asStateFlow()

    private val _question = MutableStateFlow(generateQuestion())
    val question = _question.asStateFlow()

    private val _showAdEvent = MutableStateFlow<Boolean>(false)
    val showAdEvent = _showAdEvent.asStateFlow()

    private var lastAdTimeMs: Long = 0

    fun generateNewQuestion() {
        _question.value = generateQuestion()
    }

    private fun generateQuestion(): MathQuestion {
        val num1 = Random.nextInt(20, 50)
        val num2 = Random.nextInt(1, 20)
        // Ensure num1 > num2 to avoid negative answers for simplicity
        return MathQuestion(num1, num2, Random.nextBoolean())
    }

    fun submitAnswer(userAnswer: String, onCorrect: () -> Unit, onIncorrect: () -> Unit) {
        val answerInt = userAnswer.toIntOrNull()
        if (answerInt == _question.value.answer) {
            val now = System.currentTimeMillis()
            if (now - lastAdTimeMs > 30_000) {
                _showAdEvent.value = true
            } else {
                addPointsAndNewQuestion()
            }
            onCorrect()
        } else {
            onIncorrect()
        }
    }

    fun onAdCompleted() {
        _showAdEvent.value = false
        lastAdTimeMs = System.currentTimeMillis()
        addPointsAndNewQuestion()
    }
    
    private fun addPointsAndNewQuestion() {
        _points.value += 10
        generateNewQuestion()
    }
    
    fun clearAdEvent() {
        _showAdEvent.value = false
    }
}
